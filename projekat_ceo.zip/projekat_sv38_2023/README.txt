Korišćene biblioteke:

JDatePicker 1.3.4
https://sourceforge.net/projects/jdatepicker/files/latest/download

XChart 3.8.8
https://knowm.org/open-source/XChart/ 

